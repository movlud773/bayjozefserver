import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, Package, ShoppingCart, Users, FileText, Settings, Image, Star, LogOut } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';

const ADMIN_NAV = [
  { label: 'Dashboard', icon: LayoutDashboard, href: '/admin' },
  { label: 'Products', icon: Package, href: '/admin/products' },
  { label: 'Orders', icon: ShoppingCart, href: '/admin/orders' },
  { label: 'Customers', icon: Users, href: '/admin/customers' },
  { label: 'Banners', icon: Image, href: '/admin/banners' },
  { label: 'Blog', icon: FileText, href: '/admin/blog' },
  { label: 'Quotes', icon: Star, href: '/admin/quotes' },
  { label: 'Settings', icon: Settings, href: '/admin/settings' },
];

export const AdminLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const { signOut, profile } = useAuth();

  return (
    <div className="flex min-h-screen w-full">
      {/* Sidebar */}
      <aside className="hidden md:flex flex-col w-60 shrink-0 bg-secondary border-r border-border">
        <div className="p-4 border-b border-border">
          <Link to="/" className="flex items-center">
            <span className="text-lg font-black text-primary">PRO</span>
            <span className="text-lg font-black text-foreground">SECURITY</span>
          </Link>
          <p className="text-xs text-primary font-semibold mt-0.5">Admin Panel</p>
        </div>
        <nav className="flex-1 p-3 flex flex-col gap-1">
          {ADMIN_NAV.map(item => (
            <Link
              key={item.href}
              to={item.href}
              className={cn(
                'flex items-center gap-2.5 px-3 py-2 text-sm rounded transition-colors',
                (location.pathname === item.href || (item.href !== '/admin' && location.pathname.startsWith(item.href)))
                  ? 'bg-primary/10 text-primary border-l-2 border-primary'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              )}
            >
              <item.icon size={16} />
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="p-3 border-t border-border">
          <div className="px-3 py-2 text-xs text-muted-foreground mb-1 truncate">{profile?.email}</div>
          <button onClick={signOut} className="flex items-center gap-2 px-3 py-2 text-sm text-destructive hover:text-destructive/80 hover:bg-muted rounded transition-colors w-full">
            <LogOut size={16} />Sign Out
          </button>
        </div>
      </aside>
      <div className="flex-1 min-w-0 overflow-x-hidden flex flex-col">
        <div className="flex-1 p-4 md:p-6">{children}</div>
      </div>
    </div>
  );
};
