import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Package, User, Heart, MessageSquare, FileText, LayoutDashboard, LogOut, Star, Menu, X } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

const USER_NAV = [
  { label: 'Dashboard', icon: LayoutDashboard, href: '/user' },
  { label: 'My Orders', icon: Package, href: '/user/orders' },
  { label: 'Wishlist', icon: Heart, href: '/user/wishlist' },
  { label: 'Profile', icon: User, href: '/user/profile' },
  { label: 'Messages', icon: MessageSquare, href: '/user/messages' },
  { label: 'Quote Requests', icon: FileText, href: '/user/quotes' },
  { label: 'Dealer Program', icon: Star, href: '/user/dealer' },
];

export const UserLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { signOut, profile } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const Sidebar = ({ onClose }: { onClose?: () => void }) => (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <User size={18} className="text-primary" />
          </div>
          <div className="min-w-0">
            <div className="text-sm font-semibold text-foreground truncate">{profile?.full_name || 'Customer'}</div>
            <div className="text-xs text-muted-foreground truncate">{profile?.email}</div>
            <div className="text-xs text-primary capitalize">{profile?.role}</div>
          </div>
          {onClose && (
            <Button variant="ghost" size="icon" className="ml-auto shrink-0" onClick={onClose}><X size={16} /></Button>
          )}
        </div>
      </div>
      <nav className="flex-1 p-3 flex flex-col gap-1">
        {USER_NAV.map(item => (
          <Link key={item.href} to={item.href} onClick={onClose}
            className={cn(
              'flex items-center gap-2.5 px-3 py-2 text-sm rounded transition-colors',
              location.pathname === item.href
                ? 'bg-primary/10 text-primary border-l-2 border-primary'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            )}>
            <item.icon size={16} />
            {item.label}
          </Link>
        ))}
      </nav>
      <div className="p-3 border-t border-border">
        <button onClick={handleSignOut} className="flex items-center gap-2 px-3 py-2 text-sm text-destructive hover:bg-muted rounded transition-colors w-full">
          <LogOut size={16} />Sign Out
        </button>
      </div>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex gap-6">
        {/* Desktop sidebar */}
        <aside className="hidden md:block w-56 shrink-0">
          <div className="bg-card border border-border rounded sticky top-20 overflow-hidden">
            <Sidebar />
          </div>
        </aside>

        {/* Mobile header */}
        <div className="md:hidden w-full mb-4">
          <div className="bg-card border border-border rounded p-3 flex items-center justify-between">
            <span className="text-sm font-semibold text-foreground">My Account</span>
            <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(true)}><Menu size={18} /></Button>
          </div>
          {sidebarOpen && (
            <div className="fixed inset-0 z-50 flex">
              <div className="absolute inset-0 bg-black/60" onClick={() => setSidebarOpen(false)} />
              <div className="relative w-64 bg-card border-r border-border h-full">
                <Sidebar onClose={() => setSidebarOpen(false)} />
              </div>
            </div>
          )}
        </div>

        <main className="flex-1 min-w-0">{children}</main>
      </div>
    </div>
  );
};
