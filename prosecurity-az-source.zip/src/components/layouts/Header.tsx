import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { ShoppingCart, User, Search, Menu, X, Phone, MapPin, ChevronDown, Heart, LogOut, Settings, Package, LayoutDashboard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { useAuth } from '@/contexts/AuthContext';
import { useCart } from '@/contexts/CartContext';
import { cn } from '@/lib/utils';

const NAV_LINKS = [
  { label: 'Products', href: '/products' },
  { label: 'Hikvision', href: '/products?brand=hikvision' },
  { label: 'Tools', href: '/tools' },
  { label: 'Blog', href: '/blog' },
  { label: 'Contact', href: '/contact' },
];

export const Header: React.FC = () => {
  const { user, profile, signOut, isAdmin } = useAuth();
  const { totalItems } = useCart();
  const navigate = useNavigate();
  const location = useLocation();
  const [search, setSearch] = useState('');
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) navigate(`/products?search=${encodeURIComponent(search.trim())}`);
  };

  return (
    <>
      {/* Top bar */}
      <div className="bg-secondary border-b border-border hidden md:block">
        <div className="max-w-7xl mx-auto px-4 py-1.5 flex items-center justify-between text-xs text-muted-foreground">
          <div className="flex items-center gap-6">
            <a href="tel:+994776117780" className="flex items-center gap-1.5 hover:text-foreground transition-colors">
              <Phone size={12} className="text-primary" />
              +994 77 611 77 80
            </a>
            <div className="flex items-center gap-1.5">
              <MapPin size={12} className="text-primary" />
              Baku, Azadliq prospekti 143
            </div>
            <span>09:00 – 18:00 (Mon–Sat)</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-green-400 font-medium">Free Consultation Available</span>
          </div>
        </div>
      </div>

      {/* Main header */}
      <header className={cn(
        'sticky top-0 z-50 bg-secondary border-b border-border transition-shadow',
        scrolled && 'shadow-lg shadow-black/40'
      )}>
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center gap-4 h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-0 shrink-0">
              <span className="text-2xl font-black text-primary tracking-tight">PRO</span>
              <span className="text-2xl font-black text-foreground tracking-tight">SECURITY</span>
              <span className="text-lg font-bold text-muted-foreground">.AZ</span>
            </Link>

            {/* Desktop nav */}
            <nav className="hidden lg:flex items-center gap-1 ml-6">
              {NAV_LINKS.map(link => (
                <Link
                  key={link.href}
                  to={link.href}
                  className={cn(
                    'px-3 py-2 text-sm font-medium rounded transition-colors',
                    location.pathname === link.href || location.pathname.startsWith(link.href + '?')
                      ? 'text-primary'
                      : 'text-muted-foreground hover:text-foreground'
                  )}
                >
                  {link.label}
                </Link>
              ))}
              <DropdownMenu>
                <DropdownMenuTrigger className="flex items-center gap-1 px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                  Categories <ChevronDown size={14} />
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-secondary border-border w-56">
                  {[
                    { label: 'IP Cameras', slug: 'ip-cameras' },
                    { label: 'Analog Cameras', slug: 'analog-cameras' },
                    { label: 'DVR / NVR', slug: 'dvr-nvr' },
                    { label: 'PoE Switches', slug: 'switches' },
                    { label: 'Cables & Accessories', slug: 'cables-accessories' },
                    { label: 'Access Control', slug: 'access-control' },
                    { label: 'Alarms', slug: 'alarms' },
                    { label: 'PTZ Cameras', slug: 'ptz-cameras' },
                  ].map(c => (
                    <DropdownMenuItem key={c.slug} asChild>
                      <Link to={`/products?category=${c.slug}`} className="cursor-pointer">{c.label}</Link>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </nav>

            {/* Search */}
            <form onSubmit={handleSearch} className="flex-1 max-w-md hidden md:flex">
              <div className="relative w-full">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                <Input
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Search cameras, NVR, accessories..."
                  className="pl-9 bg-background border-border h-9 text-sm"
                />
              </div>
            </form>

            <div className="flex items-center gap-2 ml-auto">
              {/* WhatsApp */}
              <a
                href="https://wa.me/994776117780"
                target="_blank"
                rel="noopener noreferrer"
                className="hidden md:flex items-center gap-1.5 px-3 py-1.5 bg-green-700 hover:bg-green-600 text-white text-xs font-semibold rounded transition-colors"
              >
                <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                Order via WhatsApp
              </a>

              {/* Wishlist */}
              {user && (
                <Link to="/user/wishlist">
                  <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                    <Heart size={18} />
                  </Button>
                </Link>
              )}

              {/* Cart */}
              <Link to="/cart" className="relative">
                <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                  <ShoppingCart size={18} />
                  {totalItems > 0 && (
                    <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 text-xs flex items-center justify-center bg-primary text-primary-foreground">
                      {totalItems > 9 ? '9+' : totalItems}
                    </Badge>
                  )}
                </Button>
              </Link>

              {/* User */}
              {user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                      <User size={18} />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-secondary border-border w-52">
                    <div className="px-3 py-2 text-xs text-muted-foreground border-b border-border">
                      <div className="font-semibold text-foreground truncate">{profile?.full_name || profile?.email}</div>
                      <div className="capitalize text-primary">{profile?.role}</div>
                    </div>
                    <DropdownMenuItem asChild><Link to="/user" className="cursor-pointer"><Package size={14} className="mr-2" />My Orders</Link></DropdownMenuItem>
                    <DropdownMenuItem asChild><Link to="/user/profile" className="cursor-pointer"><Settings size={14} className="mr-2" />Profile</Link></DropdownMenuItem>
                    {isAdmin && (
                      <>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild>
                          <Link to="/admin" className="cursor-pointer text-primary">
                            <LayoutDashboard size={14} className="mr-2" />Admin Panel
                          </Link>
                        </DropdownMenuItem>
                      </>
                    )}
                    {profile?.role === 'dealer' && profile.dealer_status === 'approved' && (
                      <DropdownMenuItem asChild><Link to="/dealer" className="cursor-pointer text-yellow-400"><LayoutDashboard size={14} className="mr-2" />Dealer Panel</Link></DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={signOut} className="text-destructive cursor-pointer">
                      <LogOut size={14} className="mr-2" />Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Link to="/auth">
                  <Button size="sm" className="bg-primary text-primary-foreground hover:bg-accent text-xs">Sign In</Button>
                </Link>
              )}

              {/* Mobile menu */}
              <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="lg:hidden text-muted-foreground">
                    <Menu size={20} />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="bg-secondary border-border w-72 p-0">
                  <div className="flex items-center justify-between p-4 border-b border-border">
                    <Link to="/" onClick={() => setMobileOpen(false)} className="flex items-center">
                      <span className="text-xl font-black text-primary">PRO</span>
                      <span className="text-xl font-black text-foreground">SECURITY.AZ</span>
                    </Link>
                    <Button variant="ghost" size="icon" onClick={() => setMobileOpen(false)}>
                      <X size={18} />
                    </Button>
                  </div>
                  <form onSubmit={(e) => { handleSearch(e); setMobileOpen(false); }} className="p-4 border-b border-border">
                    <div className="relative">
                      <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                      <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search products..." className="pl-9 bg-background border-border text-sm h-9" />
                    </div>
                  </form>
                  <nav className="p-4 flex flex-col gap-1">
                    {NAV_LINKS.map(link => (
                      <Link key={link.href} to={link.href} onClick={() => setMobileOpen(false)}
                        className="px-3 py-2.5 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors">
                        {link.label}
                      </Link>
                    ))}
                    <div className="border-t border-border my-2" />
                    {[
                      { label: 'IP Cameras', slug: 'ip-cameras' }, { label: 'Analog Cameras', slug: 'analog-cameras' },
                      { label: 'DVR / NVR', slug: 'dvr-nvr' }, { label: 'PoE Switches', slug: 'switches' },
                      { label: 'Access Control', slug: 'access-control' }, { label: 'PTZ Cameras', slug: 'ptz-cameras' },
                    ].map(c => (
                      <Link key={c.slug} to={`/products?category=${c.slug}`} onClick={() => setMobileOpen(false)}
                        className="px-3 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors">
                        {c.label}
                      </Link>
                    ))}
                  </nav>
                  <div className="p-4 border-t border-border">
                    <a href="https://wa.me/994776117780" target="_blank" rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 w-full py-2.5 bg-green-700 hover:bg-green-600 text-white text-sm font-semibold rounded transition-colors">
                      WhatsApp: +994 77 611 77 80
                    </a>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </header>
    </>
  );
};
