import React, { useState, useEffect, useCallback } from 'react';
import { Shield, UserCheck, UserX, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { adminFetchAllProfiles, adminUpdateProfile } from '@/services/api';
import { toast } from 'sonner';
import type { Profile } from '@/types/types';

const AdminCustomers: React.FC = () => {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [count, setCount] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const LIMIT = 15;

  const load = useCallback(() => {
    setLoading(true);
    adminFetchAllProfiles(page, LIMIT)
      .then(({ data, count }) => { setProfiles(data); setCount(count); })
      .catch(console.error).finally(() => setLoading(false));
  }, [page]);

  useEffect(() => { load(); }, [load]);

  const handleDealerApprove = async (id: string) => {
    await adminUpdateProfile(id, { dealer_status: 'approved', role: 'dealer' });
    toast.success('Dealer approved!');
    load();
  };

  const handleDealerReject = async (id: string) => {
    await adminUpdateProfile(id, { dealer_status: 'rejected' });
    toast.success('Dealer application rejected');
    load();
  };

  const handleMakeAdmin = async (id: string) => {
    if (!confirm('Make this user an admin?')) return;
    await adminUpdateProfile(id, { role: 'admin' });
    toast.success('User promoted to admin');
    load();
  };

  const ROLE_COLORS: Record<string, string> = {
    admin: 'bg-primary/10 text-primary border-primary/20',
    dealer: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
    customer: 'bg-muted text-muted-foreground border-border',
  };

  const DEALER_STATUS_COLORS: Record<string, string> = {
    none: 'bg-muted text-muted-foreground',
    pending: 'bg-yellow-500/10 text-yellow-400',
    approved: 'bg-green-500/10 text-green-400',
    rejected: 'bg-destructive/10 text-destructive',
  };

  const totalPages = Math.ceil(count / LIMIT);

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold text-foreground">Customers ({count})</h1>

      <Card className="bg-card border-border">
        <div className="overflow-x-auto">
          <table className="w-full whitespace-nowrap">
            <thead>
              <tr className="border-b border-border">
                {['Name / Email', 'Role', 'Dealer Status', 'Phone', 'Joined', 'Actions'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <tr key={i} className="border-b border-border/50">
                    {Array.from({ length: 6 }).map((_, j) => <td key={j} className="px-4 py-3"><div className="h-4 bg-muted rounded animate-pulse" /></td>)}
                  </tr>
                ))
              ) : profiles.map(p => (
                <tr key={p.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                  <td className="px-4 py-3">
                    <div className="font-medium text-foreground text-sm">{p.full_name || '—'}</div>
                    <div className="text-xs text-muted-foreground">{p.email}</div>
                  </td>
                  <td className="px-4 py-3">
                    <Badge className={`text-xs border capitalize ${ROLE_COLORS[p.role] ?? ''}`}>{p.role}</Badge>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-xs font-medium capitalize px-2 py-0.5 rounded ${DEALER_STATUS_COLORS[p.dealer_status ?? 'none'] ?? ''}`}>
                      {p.dealer_status ?? 'none'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{p.phone ?? '—'}</td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{new Date(p.created_at).toLocaleDateString()}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1">
                      {p.dealer_status === 'pending' && (
                        <>
                          <Button variant="ghost" size="sm" className="h-7 text-xs text-green-400 hover:bg-green-900/20 border border-green-700/30" onClick={() => handleDealerApprove(p.id)}>
                            <UserCheck size={12} className="mr-1" />Approve
                          </Button>
                          <Button variant="ghost" size="sm" className="h-7 text-xs text-destructive hover:bg-destructive/10 border border-destructive/30" onClick={() => handleDealerReject(p.id)}>
                            <UserX size={12} className="mr-1" />Reject
                          </Button>
                        </>
                      )}
                      {p.role === 'customer' && (
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-primary" title="Make Admin" onClick={() => handleMakeAdmin(p.id)}>
                          <Shield size={13} />
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {totalPages > 1 && (
        <div className="flex justify-center gap-2">
          <Button variant="ghost" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)} className="border border-border"><ChevronLeft size={16} /></Button>
          <span className="flex items-center text-sm text-muted-foreground px-3">Page {page} / {totalPages}</span>
          <Button variant="ghost" size="sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)} className="border border-border"><ChevronRight size={16} /></Button>
        </div>
      )}
    </div>
  );
};

export default AdminCustomers;
