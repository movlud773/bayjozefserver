import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { HardDrive, Eye, Zap, Wifi, Cable, Server, Radio } from 'lucide-react';

// ─── HDD Calculator ───────────────────────────────────────────────────
const HddCalculator: React.FC = () => {
  const [cameras, setCameras] = useState(4);
  const [res, setRes] = useState('2');
  const [fps, setFps] = useState(15);
  const [days, setDays] = useState(30);
  const [hours, setHours] = useState(24);
  const [result, setResult] = useState<string | null>(null);

  const RES_BITRATES: Record<string, number> = { '1': 1024, '2': 2048, '4': 4096, '8': 8192 };

  const calculate = () => {
    const bitrate = (RES_BITRATES[res] ?? 2048) * (fps / 25);
    const totalGB = (cameras * bitrate * 3600 * hours * days) / (8 * 1024 * 1024 * 1024);
    const recommended = totalGB * 1.2;
    setResult(`Total storage: ${totalGB.toFixed(1)} GB | Recommended HDD: ${recommended.toFixed(0)} GB (${(recommended / 1000).toFixed(1)} TB)`);
  };

  return (
    <Card className="bg-card border-border p-5">
      <div className="flex items-center gap-2 mb-4">
        <HardDrive size={20} className="text-primary" />
        <h3 className="text-base font-bold text-foreground">HDD Capacity Calculator</h3>
      </div>
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Number of Cameras</label>
          <Input type="number" min={1} max={64} value={cameras} onChange={e => setCameras(+e.target.value)} className="bg-muted border-border h-9 text-sm" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Resolution (MP)</label>
          <Select value={res} onValueChange={setRes}>
            <SelectTrigger className="bg-muted border-border h-9 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent className="bg-secondary border-border">
              <SelectItem value="1">1MP (720p)</SelectItem>
              <SelectItem value="2">2MP (1080p)</SelectItem>
              <SelectItem value="4">4MP (2K)</SelectItem>
              <SelectItem value="8">8MP (4K)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Frame Rate (FPS)</label>
          <Input type="number" min={1} max={30} value={fps} onChange={e => setFps(+e.target.value)} className="bg-muted border-border h-9 text-sm" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Recording Hours/Day</label>
          <Input type="number" min={1} max={24} value={hours} onChange={e => setHours(+e.target.value)} className="bg-muted border-border h-9 text-sm" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Retention Days</label>
          <Input type="number" min={1} max={365} value={days} onChange={e => setDays(+e.target.value)} className="bg-muted border-border h-9 text-sm" />
        </div>
      </div>
      <Button className="w-full bg-primary text-primary-foreground hover:bg-accent" onClick={calculate}>Calculate</Button>
      {result && <div className="mt-3 p-3 bg-primary/10 border border-primary/20 rounded text-sm text-primary font-medium">{result}</div>}
    </Card>
  );
};

// ─── Lens FOV Calculator ───────────────────────────────────────────────
const LensCalculator: React.FC = () => {
  const [focal, setFocal] = useState(2.8);
  const [sensor, setSensor] = useState('1/2.8');
  const [result, setResult] = useState<string | null>(null);

  const SENSOR_SIZES: Record<string, { w: number; h: number }> = {
    '1/2.8': { w: 6.35, h: 4.76 },
    '1/3': { w: 6.0, h: 4.5 },
    '1/2.7': { w: 6.6, h: 5.0 },
    '1/1.8': { w: 7.18, h: 5.32 },
  };

  const calculate = () => {
    const s = SENSOR_SIZES[sensor] ?? SENSOR_SIZES['1/2.8'];
    const hFov = (2 * Math.atan(s.w / (2 * focal)) * 180) / Math.PI;
    const vFov = (2 * Math.atan(s.h / (2 * focal)) * 180) / Math.PI;
    const covAt10m = 2 * 10 * Math.tan((hFov * Math.PI) / 360);
    setResult(`Horizontal FOV: ${hFov.toFixed(1)}° | Vertical FOV: ${vFov.toFixed(1)}° | Coverage at 10m: ${covAt10m.toFixed(1)}m wide`);
  };

  return (
    <Card className="bg-card border-border p-5">
      <div className="flex items-center gap-2 mb-4">
        <Eye size={20} className="text-primary" />
        <h3 className="text-base font-bold text-foreground">Lens Angle (FOV) Simulator</h3>
      </div>
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Focal Length (mm)</label>
          <Input type="number" min={1.4} max={100} step={0.1} value={focal} onChange={e => setFocal(+e.target.value)} className="bg-muted border-border h-9 text-sm" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Sensor Size</label>
          <Select value={sensor} onValueChange={setSensor}>
            <SelectTrigger className="bg-muted border-border h-9 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent className="bg-secondary border-border">
              <SelectItem value="1/1.8">1/1.8" (large)</SelectItem>
              <SelectItem value="1/2.7">1/2.7"</SelectItem>
              <SelectItem value="1/2.8">1/2.8" (standard)</SelectItem>
              <SelectItem value="1/3">1/3"</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <Button className="w-full bg-primary text-primary-foreground hover:bg-accent" onClick={calculate}>Calculate FOV</Button>
      {result && <div className="mt-3 p-3 bg-primary/10 border border-primary/20 rounded text-sm text-primary font-medium">{result}</div>}
    </Card>
  );
};

// ─── PoE Calculator ───────────────────────────────────────────────────
const PoeCalculator: React.FC = () => {
  const [cameras, setCameras] = useState(4);
  const [poeStd, setPoeStd] = useState('802.3at');
  const [result, setResult] = useState<string | null>(null);

  const WATTS: Record<string, number> = { '802.3af': 15.4, '802.3at': 30, '802.3bt': 60 };

  const calculate = () => {
    const wPerPort = WATTS[poeStd] ?? 30;
    const total = cameras * wPerPort;
    const switchBudget = total * 1.2;
    setResult(`Per-camera power: ${wPerPort}W | Total load: ${total}W | Recommended switch budget: ${switchBudget.toFixed(0)}W`);
  };

  return (
    <Card className="bg-card border-border p-5">
      <div className="flex items-center gap-2 mb-4">
        <Zap size={20} className="text-primary" />
        <h3 className="text-base font-bold text-foreground">PoE Power Calculator</h3>
      </div>
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Number of Cameras</label>
          <Input type="number" min={1} max={64} value={cameras} onChange={e => setCameras(+e.target.value)} className="bg-muted border-border h-9 text-sm" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">PoE Standard</label>
          <Select value={poeStd} onValueChange={setPoeStd}>
            <SelectTrigger className="bg-muted border-border h-9 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent className="bg-secondary border-border">
              <SelectItem value="802.3af">802.3af (15.4W)</SelectItem>
              <SelectItem value="802.3at">802.3at / PoE+ (30W)</SelectItem>
              <SelectItem value="802.3bt">802.3bt / PoE++ (60W)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <Button className="w-full bg-primary text-primary-foreground hover:bg-accent" onClick={calculate}>Calculate Power</Button>
      {result && <div className="mt-3 p-3 bg-primary/10 border border-primary/20 rounded text-sm text-primary font-medium">{result}</div>}
    </Card>
  );
};

// ─── Bandwidth Calculator ─────────────────────────────────────────────
const BandwidthCalculator: React.FC = () => {
  const [cameras, setCameras] = useState(4);
  const [res, setRes] = useState('2');
  const [codec, setCodec] = useState('h265plus');
  const [result, setResult] = useState<string | null>(null);

  const BASE_KBPS: Record<string, number> = { '1': 512, '2': 1024, '4': 2048, '8': 4096 };
  const CODEC_FACTOR: Record<string, number> = { 'h264': 1.0, 'h265': 0.5, 'h265plus': 0.3 };

  const calculate = () => {
    const base = (BASE_KBPS[res] ?? 1024) * (CODEC_FACTOR[codec] ?? 0.5);
    const totalMbps = (cameras * base) / 1000;
    setResult(`Per camera: ${base.toFixed(0)} kbps | Total bandwidth: ${totalMbps.toFixed(2)} Mbps | Recommended uplink: ${(totalMbps * 1.3).toFixed(1)} Mbps`);
  };

  return (
    <Card className="bg-card border-border p-5">
      <div className="flex items-center gap-2 mb-4">
        <Wifi size={20} className="text-primary" />
        <h3 className="text-base font-bold text-foreground">Bandwidth Calculator</h3>
      </div>
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Number of Cameras</label>
          <Input type="number" min={1} max={64} value={cameras} onChange={e => setCameras(+e.target.value)} className="bg-muted border-border h-9 text-sm" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Resolution (MP)</label>
          <Select value={res} onValueChange={setRes}>
            <SelectTrigger className="bg-muted border-border h-9 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent className="bg-secondary border-border">
              <SelectItem value="1">1MP</SelectItem>
              <SelectItem value="2">2MP</SelectItem>
              <SelectItem value="4">4MP</SelectItem>
              <SelectItem value="8">8MP</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="col-span-2">
          <label className="text-xs text-muted-foreground mb-1 block">Codec</label>
          <Select value={codec} onValueChange={setCodec}>
            <SelectTrigger className="bg-muted border-border h-9 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent className="bg-secondary border-border">
              <SelectItem value="h264">H.264</SelectItem>
              <SelectItem value="h265">H.265</SelectItem>
              <SelectItem value="h265plus">H.265+ (Smart Coding)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <Button className="w-full bg-primary text-primary-foreground hover:bg-accent" onClick={calculate}>Calculate</Button>
      {result && <div className="mt-3 p-3 bg-primary/10 border border-primary/20 rounded text-sm text-primary font-medium">{result}</div>}
    </Card>
  );
};

// ─── Cable Length Calculator ───────────────────────────────────────────
const CableCalculator: React.FC = () => {
  const [type, setType] = useState('cat6');
  const [result, setResult] = useState<string | null>(null);

  const CABLE_INFO: Record<string, { max: number; note: string }> = {
    cat5e: { max: 100, note: 'Max 100m for PoE. Use shielded for interference-prone areas.' },
    cat6: { max: 100, note: 'Max 100m, supports 10Gbps up to 55m. Recommended for IP cameras.' },
    cat6a: { max: 100, note: 'Max 100m at 10Gbps. Best for high-resolution 4K cameras.' },
    coax_rg59: { max: 500, note: 'Max 500m for analog CVBS. Use active balun to extend.' },
    coax_rg6: { max: 1000, note: 'Max 1000m for analog. Suitable for long-distance HD-TVI/AHD.' },
    fiber: { max: 80000, note: 'Single-mode fiber: up to 80km. Multi-mode: up to 550m at 1Gbps.' },
  };

  const calculate = () => {
    const info = CABLE_INFO[type];
    if (info) setResult(`Max distance: ${info.max >= 1000 ? (info.max / 1000) + 'km' : info.max + 'm'} | ${info.note}`);
  };

  return (
    <Card className="bg-card border-border p-5">
      <div className="flex items-center gap-2 mb-4">
        <Cable size={20} className="text-primary" />
        <h3 className="text-base font-bold text-foreground">Cable Length Reference</h3>
      </div>
      <div className="mb-4">
        <label className="text-xs text-muted-foreground mb-1 block">Cable Type</label>
        <Select value={type} onValueChange={setType}>
          <SelectTrigger className="bg-muted border-border h-9 text-sm"><SelectValue /></SelectTrigger>
          <SelectContent className="bg-secondary border-border">
            <SelectItem value="cat5e">Cat5e UTP/STP</SelectItem>
            <SelectItem value="cat6">Cat6 UTP/STP</SelectItem>
            <SelectItem value="cat6a">Cat6A (Augmented)</SelectItem>
            <SelectItem value="coax_rg59">Coaxial RG59</SelectItem>
            <SelectItem value="coax_rg6">Coaxial RG6</SelectItem>
            <SelectItem value="fiber">Fiber Optic</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <Button className="w-full bg-primary text-primary-foreground hover:bg-accent" onClick={calculate}>Get Info</Button>
      {result && <div className="mt-3 p-3 bg-primary/10 border border-primary/20 rounded text-sm text-primary font-medium">{result}</div>}
    </Card>
  );
};

// ─── NVR Channel Selector ─────────────────────────────────────────────
const NvrSelector: React.FC = () => {
  const [cameras, setCameras] = useState(6);
  const [result, setResult] = useState<string | null>(null);

  const calculate = () => {
    const recommended = [4, 8, 16, 32, 64].find(c => c >= cameras) ?? 64;
    const next = [4, 8, 16, 32, 64].find(c => c > recommended) ?? 64;
    setResult(`Recommended: ${recommended}-channel NVR | For future expansion: ${next}-channel NVR. Always choose 20-30% more channels than current camera count.`);
  };

  return (
    <Card className="bg-card border-border p-5">
      <div className="flex items-center gap-2 mb-4">
        <Server size={20} className="text-primary" />
        <h3 className="text-base font-bold text-foreground">NVR Channel Selector</h3>
      </div>
      <div className="mb-4">
        <label className="text-xs text-muted-foreground mb-1 block">Number of IP Cameras</label>
        <Input type="number" min={1} max={64} value={cameras} onChange={e => setCameras(+e.target.value)} className="bg-muted border-border h-9 text-sm" />
      </div>
      <Button className="w-full bg-primary text-primary-foreground hover:bg-accent" onClick={calculate}>Recommend NVR</Button>
      {result && <div className="mt-3 p-3 bg-primary/10 border border-primary/20 rounded text-sm text-primary font-medium">{result}</div>}
    </Card>
  );
};

// ─── Fiber Distance Calculator ────────────────────────────────────────
const FiberCalculator: React.FC = () => {
  const [fiberType, setFiberType] = useState('single');
  const [speed, setSpeed] = useState('1gbps');
  const [result, setResult] = useState<string | null>(null);

  const DISTANCES: Record<string, Record<string, string>> = {
    single: { '1gbps': '10km (standard) up to 80km with enhanced optics', '10gbps': 'up to 40km', '40gbps': 'up to 10km' },
    multi_om3: { '1gbps': 'up to 550m', '10gbps': 'up to 300m', '40gbps': 'up to 100m' },
    multi_om4: { '1gbps': 'up to 1000m', '10gbps': 'up to 400m', '40gbps': 'up to 150m' },
  };

  const calculate = () => {
    const d = DISTANCES[fiberType]?.[speed] ?? 'N/A';
    setResult(`Max distance: ${d}`);
  };

  return (
    <Card className="bg-card border-border p-5">
      <div className="flex items-center gap-2 mb-4">
        <Radio size={20} className="text-primary" />
        <h3 className="text-base font-bold text-foreground">Fiber Distance Calculator</h3>
      </div>
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Fiber Type</label>
          <Select value={fiberType} onValueChange={setFiberType}>
            <SelectTrigger className="bg-muted border-border h-9 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent className="bg-secondary border-border">
              <SelectItem value="single">Single-mode (SMF)</SelectItem>
              <SelectItem value="multi_om3">Multi-mode OM3</SelectItem>
              <SelectItem value="multi_om4">Multi-mode OM4</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Speed</label>
          <Select value={speed} onValueChange={setSpeed}>
            <SelectTrigger className="bg-muted border-border h-9 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent className="bg-secondary border-border">
              <SelectItem value="1gbps">1 Gbps</SelectItem>
              <SelectItem value="10gbps">10 Gbps</SelectItem>
              <SelectItem value="40gbps">40 Gbps</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <Button className="w-full bg-primary text-primary-foreground hover:bg-accent" onClick={calculate}>Calculate</Button>
      {result && <div className="mt-3 p-3 bg-primary/10 border border-primary/20 rounded text-sm text-primary font-medium">{result}</div>}
    </Card>
  );
};

// ─── Main Tools Page ──────────────────────────────────────────────────
const ToolsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('hdd');

  const TABS = [
    { id: 'hdd', label: 'HDD Calculator', icon: HardDrive },
    { id: 'lens', label: 'Lens FOV', icon: Eye },
    { id: 'poe', label: 'PoE Power', icon: Zap },
    { id: 'bandwidth', label: 'Bandwidth', icon: Wifi },
    { id: 'cable', label: 'Cable Length', icon: Cable },
    { id: 'nvr', label: 'NVR Selector', icon: Server },
    { id: 'fiber', label: 'Fiber Distance', icon: Radio },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground mb-2">Smart Security Tools</h1>
        <p className="text-muted-foreground text-sm">Professional calculators to help design your security system</p>
      </div>

      {/* Tab nav */}
      <div className="flex flex-wrap gap-2 mb-6">
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-3 py-2 text-sm rounded transition-colors ${activeTab === tab.id ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:text-foreground hover:bg-secondary border border-border'}`}>
            <tab.icon size={14} />
            <span className="hidden sm:inline">{tab.label}</span>
          </button>
        ))}
      </div>

      <div className="max-w-lg">
        {activeTab === 'hdd' && <HddCalculator />}
        {activeTab === 'lens' && <LensCalculator />}
        {activeTab === 'poe' && <PoeCalculator />}
        {activeTab === 'bandwidth' && <BandwidthCalculator />}
        {activeTab === 'cable' && <CableCalculator />}
        {activeTab === 'nvr' && <NvrSelector />}
        {activeTab === 'fiber' && <FiberCalculator />}
      </div>

      <div className="mt-8 bg-card border border-border rounded p-6 text-center">
        <p className="text-sm text-muted-foreground mb-3">Need expert advice on your security system design?</p>
        <a href="https://wa.me/994776117780" target="_blank" rel="noopener noreferrer">
          <Button className="bg-green-700 hover:bg-green-600 text-white">Get Free Consultation</Button>
        </a>
      </div>
    </div>
  );
};

export default ToolsPage;
