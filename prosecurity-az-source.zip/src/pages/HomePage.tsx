import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, ShoppingCart, Star, CheckCircle, Package, Users, Award, Wrench } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { fetchBanners, fetchFeaturedProducts, fetchCategories, fetchBrands } from '@/services/api';
import { useCart } from '@/contexts/CartContext';
import type { Banner, Product, Category, Brand } from '@/types/types';

const STATS = [
  { icon: Package, value: '2500+', label: 'Products' },
  { icon: Wrench, value: '3500+', label: 'Projects' },
  { icon: Users, value: '5000+', label: 'Happy Customers' },
  { icon: Award, value: '100%', label: 'Official Warranty' },
];

const FEATURES = [
  { icon: Star, title: 'Smart Cart System', desc: 'Add products, compare, send quote — all from your account.' },
  { icon: CheckCircle, title: 'Comparison System', desc: 'Compare products by specifications, resolution, and price.' },
  { icon: Users, title: 'Dealer System', desc: 'Apply for dealer status and get 15% discount on all orders.' },
  { icon: Package, title: 'Multi-Language', desc: 'Full support in Azerbaijani, English, and Russian.' },
];

export const HeroSlider: React.FC<{ banners: Banner[] }> = ({ banners }) => {
  const [current, setCurrent] = useState(0);
  const prev = () => setCurrent(c => (c - 1 + banners.length) % banners.length);
  const next = useCallback(() => setCurrent(c => (c + 1) % banners.length), [banners.length]);

  useEffect(() => {
    if (banners.length < 2) return;
    const t = setInterval(next, 5000);
    return () => clearInterval(t);
  }, [next, banners.length]);

  if (!banners.length) return null;
  const b = banners[current];

  return (
    <div className="relative w-full overflow-hidden" style={{ height: '420px' }}>
      <img src={b.image_url} alt={b.title} className="w-full h-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/50 to-transparent" />
      <div className="absolute inset-0 flex items-center">
        <div className="max-w-7xl mx-auto px-4 w-full">
          <div className="max-w-xl animate-fade-in">
            <Badge className="badge-red mb-3">AI Powered Security Platform</Badge>
            <h1 className="text-3xl md:text-4xl font-black text-foreground leading-tight mb-3">{b.title}</h1>
            {b.subtitle && <p className="text-muted-foreground text-base mb-6">{b.subtitle}</p>}
            <div className="flex items-center gap-3">
              {b.button_text && b.link_url && (
                <Link to={b.link_url}>
                  <Button className="bg-primary text-primary-foreground hover:bg-accent">{b.button_text}</Button>
                </Link>
              )}
              <a href="https://wa.me/994776117780" target="_blank" rel="noopener noreferrer">
                <Button variant="ghost" className="border border-primary/60 text-primary hover:bg-primary/10">
                  WhatsApp Order
                </Button>
              </a>
            </div>
          </div>
        </div>
      </div>
      {banners.length > 1 && (
        <>
          <button onClick={prev} className="absolute left-3 top-1/2 -translate-y-1/2 bg-secondary/80 hover:bg-secondary text-foreground rounded p-1.5 transition-colors">
            <ChevronLeft size={20} />
          </button>
          <button onClick={next} className="absolute right-3 top-1/2 -translate-y-1/2 bg-secondary/80 hover:bg-secondary text-foreground rounded p-1.5 transition-colors">
            <ChevronRight size={20} />
          </button>
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
            {banners.map((_, i) => (
              <button key={i} onClick={() => setCurrent(i)}
                className={`w-2 h-2 rounded-full transition-colors ${i === current ? 'bg-primary' : 'bg-foreground/30'}`} />
            ))}
          </div>
        </>
      )}
    </div>
  );
};

const ProductCard: React.FC<{ product: Product }> = ({ product }) => {
  const { addToCart } = useCart();
  return (
    <Card className="bg-card border-border hover:border-primary/40 transition-all group overflow-hidden">
      <Link to={`/products/${product.slug}`}>
        <div className="aspect-square overflow-hidden bg-muted">
          <img src={product.thumbnail_url ?? ''} alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
        </div>
      </Link>
      <div className="p-4">
        {product.brands && <div className="text-xs text-primary font-semibold uppercase mb-1">{product.brands.name}</div>}
        <Link to={`/products/${product.slug}`}>
          <h3 className="text-sm font-semibold text-foreground leading-snug mb-2 line-clamp-2 hover:text-primary transition-colors">{product.name}</h3>
        </Link>
        <div className="flex items-center justify-between mt-auto">
          <span className="price-tag text-lg">₼{product.price.toFixed(2)}</span>
          <Button size="sm" className="bg-primary text-primary-foreground hover:bg-accent text-xs"
            onClick={() => addToCart(product.id)}>
            <ShoppingCart size={14} className="mr-1" />Add
          </Button>
        </div>
        {product.stock_qty < 5 && product.stock_qty > 0 && (
          <p className="text-xs text-yellow-400 mt-1">Only {product.stock_qty} left</p>
        )}
        {product.stock_qty === 0 && <p className="text-xs text-destructive mt-1">Out of stock</p>}
      </div>
    </Card>
  );
};

const HomePage: React.FC = () => {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);

  useEffect(() => {
    fetchBanners().then(setBanners).catch(console.error);
    fetchFeaturedProducts(8).then(setProducts).catch(console.error);
    fetchCategories().then(setCategories).catch(console.error);
    fetchBrands().then(setBrands).catch(console.error);
  }, []);

  return (
    <div>
      <HeroSlider banners={banners} />

      {/* Stats */}
      <div className="bg-primary/5 border-y border-border py-6">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-6">
          {STATS.map(s => (
            <div key={s.label} className="flex items-center gap-3">
              <div className="w-10 h-10 rounded bg-primary/10 flex items-center justify-center shrink-0">
                <s.icon size={20} className="text-primary" />
              </div>
              <div>
                <div className="text-xl font-black text-foreground">{s.value}</div>
                <div className="text-xs text-muted-foreground">{s.label}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12 space-y-14">
        {/* Brands */}
        <section>
          <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-widest text-center mb-6">Official Distributor</h2>
          <div className="flex flex-wrap items-center justify-center gap-8">
            {brands.map(b => (
              <Link key={b.id} to={`/products?brand=${b.slug}`}
                className="text-lg font-black text-muted-foreground hover:text-primary transition-colors">
                {b.name.toUpperCase()}
              </Link>
            ))}
          </div>
        </section>

        {/* Categories */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-foreground red-stripe pl-3">Browse by Category</h2>
            <Link to="/products" className="text-sm text-primary hover:underline">View all</Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {categories.map(cat => (
              <Link key={cat.id} to={`/products?category=${cat.slug}`}>
                <Card className="bg-card border-border hover:border-primary/40 transition-all overflow-hidden group">
                  <div className="aspect-video overflow-hidden bg-muted">
                    <img src={cat.image_url ?? ''} alt={cat.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                  </div>
                  <div className="p-3">
                    <h3 className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">{cat.name}</h3>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        {/* Featured Products */}
        {products.length > 0 && (
          <section>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-foreground red-stripe pl-3">Featured Products</h2>
              <Link to="/products" className="text-sm text-primary hover:underline">View all</Link>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {products.map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          </section>
        )}

        {/* Hikvision Showcase */}
        <section className="bg-card border border-border rounded overflow-hidden">
          <div className="grid md:grid-cols-2 gap-0">
            <div className="p-8 flex flex-col justify-center">
              <Badge className="badge-red mb-3 w-fit">Hikvision Smart Technology Center</Badge>
              <h2 className="text-2xl font-black text-foreground mb-3">AcuSense &amp; ColorVu Technology</h2>
              <p className="text-muted-foreground text-sm mb-6">
                Experience Hikvision's latest AI-powered security cameras. AcuSense reduces false alarms by 90% using deep learning. ColorVu delivers full-color images even in near-zero light conditions.
              </p>
              <div className="flex flex-wrap gap-2 mb-6">
                {['AcuSense AI Detection', 'ColorVu Night Vision', 'H.265+ Compression', 'IP67 Protection'].map(f => (
                  <span key={f} className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded">{f}</span>
                ))}
              </div>
              <Link to="/products?brand=hikvision">
                <Button className="bg-primary text-primary-foreground hover:bg-accent w-fit">Explore Hikvision</Button>
              </Link>
            </div>
            <div className="overflow-hidden min-h-48">
              <img src="https://miaoda-site-img.s3cdn.medo.dev/images/KLing_f06aa236-b5fc-4d42-8af8-7425ce2f747f.jpg"
                alt="Hikvision ColorVu Camera" className="w-full h-full object-cover" />
            </div>
          </div>
        </section>

        {/* Features */}
        <section>
          <h2 className="text-xl font-bold text-foreground red-stripe pl-3 mb-6">Platform Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {FEATURES.map(f => (
              <Card key={f.title} className="bg-card border-border p-5">
                <f.icon size={24} className="text-primary mb-3" />
                <h3 className="text-sm font-semibold text-foreground mb-1">{f.title}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">{f.desc}</p>
              </Card>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section className="bg-primary/5 border border-primary/20 rounded p-8 text-center">
          <h2 className="text-2xl font-black text-foreground mb-2">Need a Custom Quote?</h2>
          <p className="text-muted-foreground mb-6">Our technical team will help you design the perfect security system for your needs.</p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <a href="https://wa.me/994776117780" target="_blank" rel="noopener noreferrer">
              <Button className="bg-green-700 hover:bg-green-600 text-white">WhatsApp: +994 77 611 77 80</Button>
            </a>
            <Link to="/tools">
              <Button variant="ghost" className="border border-border text-foreground hover:bg-muted">Use Smart Tools</Button>
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
};

export default HomePage;
