## Vibe
- Corporate security tech editorial — Industrial precision meets professional B2B e-commerce (Soviet constructivism × Blueprint material)

## Color
- Primary: #CC0000
- On Primary: #FFFFFF
- Accent: #E53E3E
- On Accent: #FFFFFF
- Background: #0A0E1A
- Foreground: #F0F2F7
- Muted: #1C2235
- Border: #2A3150
- Secondary: #1A1F35

## Typography
- Heading: Inter (family: 'Inter', sans-serif, weight: 700, url: https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap)
- Body: Inter (family: 'Inter', sans-serif, weight: 400, url: https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap)

## Visual Language
- Core visual signature: Sharp-edge card borders with a left red accent stripe on active/featured elements; red hairline dividers on section headers
- Material & depth: Dark navy layered surfaces (Background → Muted → Secondary); subtle drop shadows with navy tint; no frosted glass
- Containers & buttons: Flat cards with Border-color outlines on Muted background; Primary red fill for CTA buttons; ghost outline buttons for secondary actions; sharp corners (radius 4px max)
- Layout rhythm: Dense information grid typical of B2B e-commerce; red accent confined to CTAs, badges, active nav states, and price labels; alternating Muted/Background stripe rows in tables

## Animation
- Entrance: Product cards fade-in + slide-up 200ms ease-out on viewport enter
- Interaction: Button press scale-down 0.97 80ms ease-in-out; nav hover underline slide-in 150ms
- Scroll / transition: Page route transitions fade 150ms; hero banner auto-slide 5s interval

## Forbidden
- Frosted glass / backdrop-blur on primary surfaces
- Large gradient color fills (gradient backgrounds on hero sections)
- Rounded pill buttons (keep sharp/slightly-rounded corners)

## Additional Notes
- Logo: "PRO" in Primary red (#CC0000), "SECURITY.AZ" in white — monospace-style bold weight
- Header: Dark navy sticky header with red logo, nav links, language switcher, cart icon, user icon
- Red used exclusively for: logo "PRO", CTA buttons, price tags, discount badges, active nav, progress indicators
- All user-visible copy in English (language switcher for AZ/EN/RU)
- Admin/Login page: split-screen with product imagery on left, form on right
